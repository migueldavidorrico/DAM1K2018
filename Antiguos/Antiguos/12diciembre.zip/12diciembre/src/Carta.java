public class Carta {
    private Palos palo;
    private Valor valor;

    public Carta(Palos palo, Valor valor) {
        this.palo = palo;
        this.valor = valor;
    }

    public double getValor(){
        return this.valor.getValor();
    }

    @Override
    public String toString() {
        return this.valor+" de "+this.palo;
    }
}
