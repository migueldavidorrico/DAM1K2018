public class PracticaFrutas {
    public static void main(String[] args) {
        Fruta[] frutas=Fruta.arrayInicial();
        System.out.println(frutas[3]);
    }
}
