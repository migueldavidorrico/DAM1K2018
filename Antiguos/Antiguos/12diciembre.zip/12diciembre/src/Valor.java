public enum Valor {
    AS(1,"uno"),DOS(2,"dos"),TRES(3,"tres"),CUATRO(4,"cuatro"),CINCO(5,"cinco"),SEIS(6,"seis"),SIETE(7,"siete"),SOTA(0.5,"media"),CABALLO(0.5,"media"),REY(0.5,"media");
    private double valor;
    private String valorCadena;
    Valor(double valor,String valorCadena){
        this.valor=valor;
        this.valorCadena=valorCadena;
    }

    public double getValor() {
        return valor;
    }
    public String getValorCadena(){
        return this.valorCadena;
    }
    @Override
    public String toString() {
        String salida=this.name().substring(0,1).toUpperCase();
        salida+=this.name().substring(1).toLowerCase();
        return salida;
    }
}
