public class PiezaFruta {
    Fruta fruta;
    double peso;
    boolean ecologica;

}
