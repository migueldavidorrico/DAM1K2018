public enum LocalOVisitante {
    LOCAL,VISITANTE;
}
