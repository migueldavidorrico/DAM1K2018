public enum Posicion {
    PORTERO, DEFENSA, MEDIO, DELANTERO;
}
