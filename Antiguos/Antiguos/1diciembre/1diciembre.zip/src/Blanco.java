public class Blanco {
}
/*
N  T
10   5 seg
20     25 seg
40    625 seg
80 390625 seg - 6510 min - 108 horas




        */