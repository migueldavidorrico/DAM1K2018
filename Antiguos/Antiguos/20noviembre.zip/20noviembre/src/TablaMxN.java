public class TablaMxN {
    public static void main(String[] args) {
        int n=5;
        int m=15;
        char c='%';


        for(int i=0;i<m;i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(c);
            }
            System.out.println();
        }





    }
}
