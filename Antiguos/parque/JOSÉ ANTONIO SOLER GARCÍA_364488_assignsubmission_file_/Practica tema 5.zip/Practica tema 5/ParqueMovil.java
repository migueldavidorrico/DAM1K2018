import javax.swing.*;
import java.awt.*;

public class ParqueMovil {
    private static ManejoDeFlota Flota;

    public static void main(String[] args) {
        Flota = new ManejoDeFlota();
        Vehiculos f=new Vehiculos();
        if (JOptionPane.showConfirmDialog((Component)null, "¿Quieres inicializar la flota con 5 vehículos?", "INICIALIZACION", 0) == 0){
            Flota.inicializaFlota();
            System.out.println(f.getNumerodeVehiculos());
            JOptionPane.showMessageDialog((Component)null,Flota.MostrarLista());
            int opciones = JOptionPane.showOptionDialog((Component)null, "Elije una opcion", "MENU", 0, -1, (Icon)null, Menu.values(), Menu.ALTA);
        }

    }
}
