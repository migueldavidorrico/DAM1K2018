public enum Menu {

        ALTA("ALTA DE VEHÍCULO"),
        BAJA("BAJA DE VEHÍCULO"),
        DATOS("DATOS DE UN VEHÍCULO"),
        LISTADO("LISTADO DE VEHÍCULOS"),
        SALIR("SALIR");

        private final String cadena;

        private Menu(String s) {
            this.cadena = s;
        }
}
