

public class ManejoDeFlota {
    private static final int VEHICULOS_MAXIMOS = 50;
    private final Vehiculos[] vehiculos = new Vehiculos[50];
    private int numeroVehiculos;


     public ManejoDeFlota(){}

     public boolean anyadirVehiculo(Vehiculos v) {
        this.vehiculos[this.numeroVehiculos++] = v;
        return true;
    }


    public void inicializaFlota() {
       this.anyadirVehiculo( new Vehiculos("4352-GHY", Modelo.FORD, 3000, 300));
       this.anyadirVehiculo(new Vehiculos("5432-BGC", Modelo.MERCEDES, 5000,234));
        this.anyadirVehiculo( new Vehiculos("1234-NKU", Modelo.MERCEDES, 3500,342));
        this.anyadirVehiculo(new Vehiculos("7865-RTW", Modelo.PEGASO, 3000, 150));
        this.anyadirVehiculo(new Vehiculos("9874-HYQ", Modelo.FORD, 2000,433));
    }


    public String MostrarLista() {
        String salida = "";
        salida = salida + "MATRÍCULA   MARCA   CARGA   KM" + "\n";
        for (int i = 0; i <this.numeroVehiculos; ++i) {
            salida = salida + this.vehiculos[i].getCadenaDatos();
            salida = salida + "\n";
        }
        return salida;
    }

}
