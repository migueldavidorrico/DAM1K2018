import javax.swing.*;
import java.awt.*;

public class Vehiculos {
    private  String matricula;
    private  Modelo modelo;
    private int cargaMaxima;
    private int kilometraje;
    private int numerodeVehiculos;

    public Vehiculos(String matricula, Modelo modelo, int cargaMaxima, int kilometraje) {
        this.kilometraje = 0;
        this.matricula = matricula;
        this.modelo = modelo;
        this.cargaMaxima = cargaMaxima;
        this.kilometraje = kilometraje;
        numerodeVehiculos++;
    }

    public Vehiculos(){}

    public String getCadenaDatos() {

        return String.format("%10s %10s %5dKg %7dkm", this.getMatricula(), this.getModelo(), this.getCargaMaxima(), this.getKilometraje());
    }

    public String getMatricula() {
        return this.matricula;
    }

    public Modelo getModelo() {
        return this.modelo;
    }

    public int getCargaMaxima() {
        return this.cargaMaxima;
    }

    public int getKilometraje() {
        return this.kilometraje;
    }

    public int getNumerodeVehiculos() {
        return numerodeVehiculos;
    }


    }



