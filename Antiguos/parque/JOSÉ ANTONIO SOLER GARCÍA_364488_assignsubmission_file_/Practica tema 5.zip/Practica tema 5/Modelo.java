public enum Modelo {
    PEGASO,MERCEDES,FORD;

}
