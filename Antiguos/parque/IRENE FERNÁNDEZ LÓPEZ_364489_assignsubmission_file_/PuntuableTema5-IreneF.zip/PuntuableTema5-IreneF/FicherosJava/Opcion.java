public enum Opcion {
    ALTA, BAJA, DATOS, LISTADO, SALIR;
}
