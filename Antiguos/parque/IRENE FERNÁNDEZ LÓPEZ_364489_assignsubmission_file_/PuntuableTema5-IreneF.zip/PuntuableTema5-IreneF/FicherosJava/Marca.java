public enum Marca {
    MERCEDES, PEGASO, FORD;
}
