public class EjecutableFlotaVehiculos {
    public static void main(String[] args) {
        ESFlotaVehiculos flotaMiguelSL = new ESFlotaVehiculos();
        flotaMiguelSL.ventanaInicializar();
    }
}
