public class FlotaVehiculos {

    private Vehiculo[] listado;

    public FlotaVehiculos(Vehiculo[] listado) {
        this.listado = listado;
    }

    public FlotaVehiculos() {
    }

    public Vehiculo[] getListado() {
        return this.listado;
    }

    public void setListado(Vehiculo[] listado) {
        this.listado = listado;
    }

    public String darAlta(String matriculaAIntroducir, String marcaAIntroducir, int cargaMaximaAIntroducir, int kilometrosAIntroducir) {

        if (getListado() == null) {
            Vehiculo[] listado = new Vehiculo[50];
            listado[0] = new Vehiculo(matriculaAIntroducir, marcaAIntroducir, cargaMaximaAIntroducir, kilometrosAIntroducir);
            setListado(listado);
            return "El nuevo vehiculo introducido tiene la matricula " + matriculaAIntroducir + ", es de la marca " + marcaAIntroducir + ", tiene una carga máxima de " + cargaMaximaAIntroducir + " kilos y ha recorrido " + kilometrosAIntroducir + " km.";
        }
        Vehiculo vehiculoAIntroducir = new Vehiculo(matriculaAIntroducir, marcaAIntroducir, cargaMaximaAIntroducir, kilometrosAIntroducir);
        for (int i = 0; i < getListado().length; i++) {
            if (getListado()[i] == null) {
                continue;
            }
            if (getListado()[i].getMatricula().equals(marcaAIntroducir)) {
                return "La matricula introducida ya esta asignada a un vehiculo en el listado.";
            }
        }
        for (int j = 0; j < getListado().length; j++) {
            if (getListado()[j] == null) {
                this.listado[j] = vehiculoAIntroducir;
                break;
            }
        }
        return "El nuevo vehiculo introducido tiene la matricula " + matriculaAIntroducir + ", es de la marca " + marcaAIntroducir + ", tiene una carga máxima de " + cargaMaximaAIntroducir + " kilos y ha recorrido " + kilometrosAIntroducir + " km.";
    }

    public String comprobarSiMatriculaExiste(String matricula) {
        if (getListado() == null) {
            return "";
        }
        for (int i = 0; i < getListado().length; i++) {
            if (getListado()[i] == null) {
                continue;
            }
            if (getListado()[i].getMatricula().equals(matricula)) {
                return "La matricula introducida ya esta asignada a un vehiculo en el listado.";
            }
        }
        return "";
    }


    public String darBaja(String matricula) {
        if (getListado() == null) {
            return "No hay vehiculos en el listado.";
        }
        for (int i = 0; i < getListado().length; i++) {
            if (getListado()[i] == null) {
                continue;
            }
            if (getListado()[i].getMatricula().equals(matricula)) {
                getListado()[i] = null;
                return "El vehiculo con la matricula " + matricula + " ha sido borrado";
            }
        }
        return "El vehiculo con la matricula " + matricula + " no se encuentra en el listado de vehiculos";
    }

    public String mostrarListado() {

        if (getListado() == null) {
            return "No hay vehiculos en el listado.";
        }
        //Ordenamos con método de intercambio
        for (int i = 0; i < (getListado().length - 1); i++) {
            for (int j = (i + 1); j < getListado().length; j++) {
                if (getListado()[j] == null) {
                    continue;
                }
                if (getListado()[i].getMatricula().compareToIgnoreCase(getListado()[j].getMatricula()) > 0) {
                    Vehiculo variableAuxiliar = this.listado[i];
                    this.listado[i] = this.listado[j];
                    this.listado[j] = variableAuxiliar;
                }
            }
        }
        String salida = "";
        int numeroVehiculo = 0;
        for (int j = 0; j < getListado().length; j++) {
            if (getListado()[j] != null) {
                numeroVehiculo++;
                salida += numeroVehiculo + ".- " + getListado()[j].mostrarDatos() + "\n";
            }
        }
        //Nos aseguramos que si el listado no muestra nada devuelva el mensaje oportuno
        if (salida.equals("")) {
            return "No hay vehiculos en el listado.";
        }
        return salida;
    }

    public String mostrarDatosVehiculoConcreto(String matricula) {

        if (getListado() == null) {
            return "No hay vehiculos en el listado.";
        }

        for (int i = 0; i < getListado().length; i++) {
            if (getListado()[i] == null) {
                continue;
            }
            if (getListado()[i].getMatricula().equals(matricula)) {
                return getListado()[i].mostrarDatos();
            }
        }
        return "No hay vehiculos con la matricula especificada.";
    }

    public Vehiculo[] inicializarFlota() {
        Vehiculo[] listado = new Vehiculo[50];
        listado[0] = new Vehiculo("YUI-9785", "Ford", 2000, 0);
        listado[1] = new Vehiculo("ADG-3567", "Ford", 750, 0);
        listado[2] = new Vehiculo("SFH-5790", "Mercedes", 1000, 2000);
        listado[3] = new Vehiculo("JIO-9745", "Seat", 750, 0);
        listado[4] = new Vehiculo("NCV-6490", "Ford", 1250, 0);
        listado[5] = new Vehiculo("NQE-3840", "Ford", 750, 4500);
        listado[6] = new Vehiculo("QTB-1084", "Mercedes", 1500, 0);
        listado[7] = new Vehiculo("DNC-9027", "Ford", 750, 0);
        listado[8] = new Vehiculo("TOP-2847", "Seat", 1000, 0);
        listado[9] = new Vehiculo("AKR-0647", "Seat", 750, 5000);
        listado[10] = new Vehiculo("ZJH-3874", "Ford", 750, 0);
        return listado;
    }
}
