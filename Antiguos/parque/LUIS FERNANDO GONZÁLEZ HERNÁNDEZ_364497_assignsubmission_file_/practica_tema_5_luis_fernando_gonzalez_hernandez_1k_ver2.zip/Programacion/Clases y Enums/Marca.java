public enum Marca {
    FORD("Ford"),MERCEDES("Mercedes"),SEAT("Seat");

    String marcaCadena;

    Marca (String marcaCadena){this.marcaCadena=marcaCadena;}

    @Override
    public String toString (){
        return marcaCadena;
    }
}
