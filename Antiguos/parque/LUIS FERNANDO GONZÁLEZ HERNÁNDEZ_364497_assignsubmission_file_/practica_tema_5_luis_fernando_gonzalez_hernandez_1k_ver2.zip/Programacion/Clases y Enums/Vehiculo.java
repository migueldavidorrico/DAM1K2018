public class Vehiculo {

    private final String matricula;
    private final String marca;
    private final int cargaMaxima;
    private int kilometros;

    public Vehiculo(String matricula, String marca, int cargaMaxima, int kilometros) {
        this.matricula = matricula;
        this.marca = marca;
        this.cargaMaxima = cargaMaxima;
        this.kilometros = kilometros;
    }

    public String getMatricula() {
        return this.matricula;
    }

    public String getMarca() {
        return this.marca;
    }

    public int getCargaMaxima() {
        return this.cargaMaxima;
    }

    public int getKilometros() {
        return this.kilometros;
    }

    public void setKilometros(int kilometros) {
        this.kilometros = kilometros;
    }

    @Override
    public String toString() {
        return "El vehículo con la matricula " + getMatricula() + " es de la marca " + getMarca() + " y soporta una carga maxima de " + getCargaMaxima() + " kilos.";
    }

    public String mostrarDatos() {
        return "El vehículo con la matricula " + getMatricula() + " es de la marca " + getMarca() + ", soporta una carga maxima de " + getCargaMaxima() + " kilos y ha recorrido " + getKilometros() + " km.";
    }
}
