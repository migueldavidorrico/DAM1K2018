import javax.swing.*;

public class ESFlotaVehiculos {

    FlotaVehiculos flotaAMostar = new FlotaVehiculos();

    public void ventanaInicializar() {
        String mensaje = "¿Quieres inicializar la flota con 11 vehiculos?";
        int seleccion = JOptionPane.showOptionDialog(null, mensaje, null, JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
        if (seleccion == 0) {
            flotaAMostar.setListado(flotaAMostar.inicializarFlota());
            ventanaVerListado();
        }
        if (seleccion == 1) {
            ventanaVerListado();
        }
    }

    public void ventanaMenuPrincipal() {
        String[] opcionesMenuPrincipal = {"Añadir", "Borrar", "Ver listado", "Buscar", "Salir"};
        int seleccion = JOptionPane.showOptionDialog(null, "Elige una opción:", "Menu principal", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, opcionesMenuPrincipal, null);
        switch (seleccion) {
            case 0:
                ventanaDarAlta();
            case 1:
                ventanaDarBaja();
            case 2:
                ventanaVerListado();
            case 3:
                ventadaMostrarDatosVehiculoConcreto();
            case 4:
                System.exit(0);
        }
    }

    public void ventanaDarAlta() {
        String entradaMatricula = JOptionPane.showInputDialog("Introduce la matricula del nuevo vehiculo");
        volverMenuSiInputDialogCancelarString(entradaMatricula);
        String entradaMatriculaMayusculas=pasarMayusculas(entradaMatricula);
        String comprobacionMatricula = flotaAMostar.comprobarSiMatriculaExiste(entradaMatricula);
        if (comprobacionMatricula != "") {
            JOptionPane.showMessageDialog(null, comprobacionMatricula);
            ventanaMenuPrincipal();
        }
        Object eleccionDeMarca = JOptionPane.showInputDialog(null, "Elije la marca que desea para el nuevo vehiculo", "Eleccion de marca", JOptionPane.OK_CANCEL_OPTION, null, Marca.values(), Marca.FORD);
        String entradaMarca = eleccionDeMarca.toString();
        volverMenuSiInputDialogCancelarString(entradaMarca);
        int entradaCargaMaxima = Integer.parseInt(JOptionPane.showInputDialog("Introduce la carga máxima del nuevo vehiculo"));
        int entradaKilometros = Integer.parseInt(JOptionPane.showInputDialog("Introduce el número de kilometros recorrido por el nuevo vehiculo"));
        JOptionPane.showMessageDialog(null, flotaAMostar.darAlta(entradaMatriculaMayusculas, entradaMarca, entradaCargaMaxima, entradaKilometros), "Información del vehiculo dado de alta", JOptionPane.INFORMATION_MESSAGE);
        volverMenuDespuesInformationMessage();
    }

    public void ventanaDarBaja() {
        String entrada = JOptionPane.showInputDialog("Introduzca la matricula del coche que desea eliminar:");
        volverMenuSiInputDialogCancelarString(entrada);
        JOptionPane.showMessageDialog(null, flotaAMostar.darBaja(entrada), "Dar de baja", JOptionPane.INFORMATION_MESSAGE);
        volverMenuDespuesInformationMessage();
    }

    public void ventanaVerListado() {
        JOptionPane.showMessageDialog(null, flotaAMostar.mostrarListado(), "Listado de vehiculos", JOptionPane.INFORMATION_MESSAGE);
        volverMenuDespuesInformationMessage();
    }

    public void ventadaMostrarDatosVehiculoConcreto() {
        String entrada = JOptionPane.showInputDialog("Introduzca la matricula del coche que desea buscar:");
        volverMenuSiInputDialogCancelarString(entrada);
        JOptionPane.showMessageDialog(null, flotaAMostar.mostrarDatosVehiculoConcreto(entrada), "Información del vehiculo buscado", JOptionPane.INFORMATION_MESSAGE);
        volverMenuDespuesInformationMessage();
    }

    public void volverMenuDespuesInformationMessage() {
        if (JOptionPane.INFORMATION_MESSAGE == 1) {
            ventanaMenuPrincipal();
        }
    }

    public void volverMenuSiInputDialogCancelarString(String variableEntrada) {
        if (variableEntrada == null) {
            ventanaMenuPrincipal();
        }
    }

    public String pasarMayusculas (String variableEntrada){
        return variableEntrada.toUpperCase();
    }
}



