public enum Marcas {
    FORD("Ford"),
    MERCEDES("Mercedes"),
    PEGASO("Pegaso");

    private String cadena;

    Marcas(String marca) {
        this.cadena = marca;
    }
}

