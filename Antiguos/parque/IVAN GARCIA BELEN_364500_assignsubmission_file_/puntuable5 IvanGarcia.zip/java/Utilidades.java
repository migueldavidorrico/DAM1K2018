import javax.swing.*;


public class Utilidades {

    //Pasa todas los caracteres de una matrícula a mayusculas. Utilizado en "comprobarMatricula" y en el programaPrincipal.
    public static String pasarAMayusculas(String stringIndroducido){
        String salida=stringIndroducido.toUpperCase();
        return salida;
    }

}


