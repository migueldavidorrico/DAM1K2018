public enum TipoMarca {


        MERCEDES, PEGASO, FORD;

         TipoMarca() {
        }

        public String toString() {
            return Utilidades.PrimeraMayusculas(this.name());
        }
    }

