import java.awt.Component;
import javax.swing.Icon;
import javax.swing.JOptionPane;

public class TipoVehiculo {
    public TipoVehiculo() {
    }

    public static Vehiculo pideVehiculo() {
        String matricula = JOptionPane.showInputDialog((Component)null, "Introduzca la Matrícula");
        if (matricula == null) {
            return null;
        } else {
            TipoMarca marca = (TipoMarca)JOptionPane.showInputDialog((Component)null, "Introduzca la marca", "MARCA", 0, (Icon)null, TipoMarca.values(), TipoMarca.FORD);
            if (marca == null) {
                return null;
            } else {
                String cadenaCarga = JOptionPane.showInputDialog((Component)null, "Introduzca la carga máxima");
                if (cadenaCarga == null) {
                    return null;
                } else {
                    int carga = Integer.parseInt(cadenaCarga);
                    Vehiculo v = new Vehiculo(matricula, marca, carga);
                    return v;
                }
            }
        }
    }
}
