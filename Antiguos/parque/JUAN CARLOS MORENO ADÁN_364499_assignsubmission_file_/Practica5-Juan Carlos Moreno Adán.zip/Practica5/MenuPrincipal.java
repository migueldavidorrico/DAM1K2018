import java.awt.Component;
import javax.swing.Icon;
import javax.swing.JOptionPane;
public class MenuPrincipal {
        private static Taller taller;

        public MenuPrincipal() {
        }

        public static void main(String[] args) {
            taller = new Taller();
            if (JOptionPane.showConfirmDialog((Component)null, "¿Quieres iniciar el taller con 5 vehículos?", "INICIALIZACIÓN", 0) == 0) {
                taller.inicializaTaller();
            }

            JOptionPane.showMessageDialog((Component)null, taller.getCadenaListadoHTML());

            OpcionDeMenu elegida;
            do {
                int opcion = JOptionPane.showOptionDialog((Component)null, "Elija una opción", "MENÚ", 0, -1, (Icon)null, OpcionDeMenu.values(), OpcionDeMenu.ALTA);
                elegida = OpcionDeMenu.values()[opcion];
                Vehiculo[] buenos;
                Vehiculo v;
                switch(elegida) {
                    case DATOS:
                        buenos = taller.vehiculosBuenos();
                        if (buenos.length > 0) {
                            v = (Vehiculo)JOptionPane.showInputDialog((Component)null, "Elija un vehículo", "Lista", 3, (Icon)null, buenos, buenos[0]);
                            if (v != null) {
                                JOptionPane.showMessageDialog((Component)null, v.getCadenaDatos());
                            }
                        } else {
                            JOptionPane.showMessageDialog((Component)null, "La lista está vacía");
                        }
                        break;
                    case BAJA:
                        buenos = taller.vehiculosBuenos();
                        if (buenos.length > 0) {
                            v = (Vehiculo)JOptionPane.showInputDialog((Component)null, "Elija un vehículo", "Lista", 3, (Icon)null, buenos, buenos[0]);
                            taller.borraVehiculo(v);
                        } else {
                            JOptionPane.showMessageDialog((Component)null, "La lista está vacía");
                        }
                        break;
                    case ALTA:
                        v = TipoVehiculo.pideVehiculo();
                        if (v == null) {
                            JOptionPane.showMessageDialog((Component)null, "Alta cancelada");
                        } else if (taller.buscarVehiculo(v) != -1) {
                            JOptionPane.showMessageDialog((Component)null, "El vehículo ya existe");
                        } else {
                            taller.sumarVehiculo(v);
                        }
                        break;
                    case LISTADO:
                        JOptionPane.showMessageDialog((Component)null, taller.getCadenaListadoHTML());
                }
            } while(elegida != OpcionDeMenu.SALIR);

        }

}
