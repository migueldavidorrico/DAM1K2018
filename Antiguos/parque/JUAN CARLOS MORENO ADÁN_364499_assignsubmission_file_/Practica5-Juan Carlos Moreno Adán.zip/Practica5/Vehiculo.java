public class Vehiculo {
    private final String matricula;
    private final TipoMarca marca;
    private int cargaMaxima;
    private int kilometros;

    public String getCadenaDatos() {
        return String.format("%10s %10s %5dKg %7dkm", this.getMatricula(), this.getTipoMarca(), this.getCargaMaxima(), this.getKilometros());
    }

    public String getMatricula() {
        return this.matricula;
    }

    public TipoMarca getTipoMarca() {
        return this.marca;
    }

    public int getCargaMaxima() {
        return this.cargaMaxima;
    }

    public void setCargaMaxima(int cargaMaxima) {
        this.cargaMaxima = cargaMaxima;
    }

    public int getKilometros() {
        return this.kilometros;
    }

    public void setKilometros(int kilometros) {
        this.kilometros = kilometros;
    }

    public Vehiculo(String matricula, TipoMarca marca, int cargaMaxima, int kilometros) {
        this.kilometros = 0;
        this.matricula = matricula;
        this.marca = marca;
        this.cargaMaxima = cargaMaxima;
        this.kilometros = kilometros;
    }

    public String toString() {
        return this.matricula;
    }

    public Vehiculo(String matricula, TipoMarca marca, int cargaMaxima) {
        this(matricula, marca, cargaMaxima, 0);
    }
}
