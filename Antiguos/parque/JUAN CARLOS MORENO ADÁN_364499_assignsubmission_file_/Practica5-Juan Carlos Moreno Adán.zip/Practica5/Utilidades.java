
public class Utilidades {
    public Utilidades() {
    }

    public static String PrimeraMayusculas(String cadena) {
        String salida = cadena.substring(0, 1).toUpperCase();
        salida = salida + cadena.substring(1).toLowerCase();
        return salida;
    }
}
