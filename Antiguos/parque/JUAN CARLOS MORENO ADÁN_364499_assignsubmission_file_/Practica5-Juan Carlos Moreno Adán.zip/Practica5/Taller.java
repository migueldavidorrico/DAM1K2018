public class Taller {
        private static final int MAX_VEHICULOS = 50;
        private final Vehiculo[] vehiculos = new Vehiculo[50];
        private int numeroVehiculos;

        public Taller() {
        }

        public static void main(String[] args) {
            Taller t = new Taller();
            t.inicializaTaller();
            System.out.println(t.getCadenaListado("\n"));
        }

        public Vehiculo[] vehiculosBuenos() {
            Vehiculo[] salida = new Vehiculo[this.numeroVehiculos];

            for(int i = 0; i < this.numeroVehiculos; ++i) {
                salida[i] = this.vehiculos[i];
            }

            return salida;
        }

        public boolean sumarVehiculo(Vehiculo v) {
            if (this.numeroVehiculos == 50) {
                return false;
            } else {
                this.vehiculos[this.numeroVehiculos++] = v;
                return true;
            }
        }

        public String getCadenaListadoHTML() {
            String salida = "<HTML><h2>LISTADO DE VEHÍCULOS</h2><hr/><pre style=\"font-size:130%\">";
            salida = salida + this.getCadenaListado("<br/>");
            salida = salida + "</pre><hr/></html>";
            System.out.println(salida);
            return salida;
        }

        public String getCadenaListado(String retornoCoche) {
            String cadena = "";
            if (this.numeroVehiculos == 0) {
                return "No hay vehículos todavía";
            } else {
                cadena = cadena + String.format("%10s %10s %6s %8s     " + retornoCoche, "MATRÍCULA", "MARCA", "CARGA", "KM");

                for(int i = 0; i < this.numeroVehiculos; ++i) {
                    cadena = cadena + this.vehiculos[i].getCadenaDatos() + retornoCoche;
                }

                return cadena;
            }
        }

        public void inicializaTaller() {
            this.sumarVehiculo(new Vehiculo("6578-GHB", TipoMarca.MERCEDES, 2000));
            this.sumarVehiculo(new Vehiculo("3435-CDG", TipoMarca.PEGASO, 1500,27000));
            this.sumarVehiculo(new Vehiculo("7632-DSA", TipoMarca.FORD, 4350,100));
            this.sumarVehiculo(new Vehiculo("0018-BMV", TipoMarca.FORD, 1000));
            this.sumarVehiculo(new Vehiculo("1221-AJX", TipoMarca.MERCEDES, 2500));
        }

        public int buscarVehiculo(Vehiculo v) {
            for(int i = 0; i < this.numeroVehiculos; ++i) {
                if (this.vehiculos[i].getMatricula().equals(v.getMatricula())) {
                    return i;
                }
            }

            return -1;
        }

        public void borraVehiculo(Vehiculo v) {
            int posicion = this.buscarVehiculo(v);

            for(int i = posicion; i < this.numeroVehiculos - 1; ++i) {
                this.vehiculos[i] = this.vehiculos[i + 1];
            }

            --this.numeroVehiculos;
        }
}
