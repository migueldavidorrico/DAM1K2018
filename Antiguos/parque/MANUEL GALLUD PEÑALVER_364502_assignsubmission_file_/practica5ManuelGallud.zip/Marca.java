public enum Marca {
    Mercedes,
    Pegaso,
    Ford
}
