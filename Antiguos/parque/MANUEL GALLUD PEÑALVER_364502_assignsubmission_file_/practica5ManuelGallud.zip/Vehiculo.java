public class Vehiculo {

    private final Marca marca;
    private final String matricula;
    private final int cargaMaxima;
    private int kilometraje;

    public Vehiculo(Marca marca, String matricula, int cargaMaxima, int kilometraje) {
        this.marca = marca;
        this.matricula = matricula;
        this.cargaMaxima = cargaMaxima;
        this.kilometraje = kilometraje;
    }

    public String devuelveDatos(){
        return "<td>"+ matricula + "</td><td>" + marca + "</td><td> " + cargaMaxima + "Kg</td><td> " + kilometraje+"km</td>";
    }

    @Override
    public String toString() {
        return matricula + "\t " + marca + "\t " + cargaMaxima + "Kg\t " + kilometraje+"km";
    }

    public int getKilometraje() {
        return kilometraje;
    }

    public void setKilometraje(int kilometraje) {
        this.kilometraje = kilometraje;
    }

    public Marca getMarca() {
        return marca;
    }

    public String getMatricula() {
        return matricula;
    }

    public int getCargaMaxima() {
        return cargaMaxima;
    }
}
