import javax.swing.*;

public class ParqueMovil {
    private static final int MAXIMO_VEHICULOS = 50;
    private Vehiculo[] vehiculos = new Vehiculo[MAXIMO_VEHICULOS];
    private int numeroVehiculos = 0;

    public static ParqueMovil inicializaParqueMovil() {
        ParqueMovil nuevo = new ParqueMovil();

        int inicializa = JOptionPane.showConfirmDialog(null, "¿Desea inicializar la flota?",
                "INICIALIZACIÓN", JOptionPane.YES_NO_OPTION);
        if (inicializa == JOptionPane.YES_OPTION) {
            nuevo.anyadirVehiculo(new Vehiculo(Marca.Ford, "7755-GDN", 2000, 300));
            nuevo.anyadirVehiculo(new Vehiculo(Marca.Mercedes, "A-1254-LL", 1000, 300000));
            nuevo.anyadirVehiculo(new Vehiculo(Marca.Pegaso, "3455-BCF", 1500, 12300));
            nuevo.anyadirVehiculo(new Vehiculo(Marca.Pegaso, "1448-CFP", 500, 0));
            nuevo.anyadirVehiculo(new Vehiculo(Marca.Ford, "5841-JJJ", 2200, 0));
        }

        nuevo.listadoVehiculos();

        return nuevo;
    }

    public boolean anyadirVehiculo(Vehiculo v) {
        if (numeroVehiculos == MAXIMO_VEHICULOS) {
            JOptionPane.showMessageDialog(null, "Has alcanzado el número máximo de vehículos");
            return false;
        }

        vehiculos[numeroVehiculos++] = v;
        return true;
    }

    public boolean altaVehiculo() {

        String matricula = JOptionPane.showInputDialog(null, "Introduce la matrícula");
        if (matricula == null || matricula.isEmpty()) return false;
        for (int i=0;i<numeroVehiculos;i++){
            if(vehiculos[i].getMatricula().equals(matricula)){
                JOptionPane.showMessageDialog(null,"La matrícula ya existe",
                        "ERROR",JOptionPane.WARNING_MESSAGE);
                return false;
            }
        }
        Marca marca = (Marca) JOptionPane.showInputDialog(null, "Selecciona la marca del vehículo",
                "MARCA", JOptionPane.OK_OPTION,null, Marca.values(),Marca.Ford);
        if (marca == null) return false;

        String cadenaCarga = JOptionPane.showInputDialog(null, "Introduce la carga máxima");
        if (cadenaCarga == null || cadenaCarga.isEmpty()) return false;
        int carga = Integer.parseInt(cadenaCarga);

        String cadenaKm = JOptionPane.showInputDialog(null,
                "¿Cúantos kilómetros recorridos lleva el vehículo?");
        if (cadenaKm == null || cadenaKm.isEmpty()) return false;
        int kilometraje= Integer.parseInt(cadenaKm);


        if (!anyadirVehiculo(new Vehiculo(marca,matricula,carga,kilometraje)))
            return false;

        return true;
    }

    public boolean bajaVehiculo() {
        boolean encontrado = false;
        String matricula = seleccionarVehiculo();
        int posicionABorrar;
        for (posicionABorrar = 0; posicionABorrar < numeroVehiculos; posicionABorrar++) {
            if (vehiculos[posicionABorrar].getMatricula().equals(matricula)) {
                encontrado = true;
                break;
            }
        }

        for (int i = posicionABorrar; i < numeroVehiculos - 1; i++) {
            vehiculos[i] = vehiculos[i + 1];
        }
        numeroVehiculos--;

        return encontrado;
    }

    private void ordenarPorMatricula() {
        for (int i = 0; i < numeroVehiculos - 1; i++) {
            String minimo = vehiculos[i].getMatricula();
            int posicionMinimo = i;
            for (int j = i + 1; j < numeroVehiculos; j++) {
                if (vehiculos[j].getMatricula().compareTo(minimo) < 0) {
                    minimo = vehiculos[j].getMatricula();
                    posicionMinimo = j;
                }
            }
            if (posicionMinimo != i) {
                Vehiculo temp = vehiculos[posicionMinimo];
                vehiculos[posicionMinimo] = vehiculos[i];
                vehiculos[i] = temp;
            }
        }
    }

    public void listadoVehiculos() {
        String salida = "<html><h1 style=\"font-family:Arial;\">LISTADO DE VEHÍCULOS<hr /></h1>";

        ordenarPorMatricula();

        if (numeroVehiculos > 0) {
            salida += "<tr><td>MATRÍCULA</td><td> MARCA</td><td> CARGA</td><td> KM </td><br /></tr>";
            for (int i = 0; i < numeroVehiculos; i++) {
                salida += "<tr>" + vehiculos[i].devuelveDatos() + "</tr>";
            }
        } else {
            salida += "No hay vehículos todavía<br />";
        }
        salida += "<hr />";
        JOptionPane.showMessageDialog(null, salida);

    }

    public String seleccionarVehiculo() {
        String[] matriculas = new String[numeroVehiculos];
        for (int i = 0; i < numeroVehiculos; i++) {
            matriculas[i] = vehiculos[i].getMatricula();
        }
        String matricula = (String) JOptionPane.showInputDialog(null, "Elija un vehículo",
                "Carrera", JOptionPane.DEFAULT_OPTION, null, matriculas, matriculas[0]);

        return matricula;
    }

    public void mostrarDatos() {
        String matriculaSeleccionada = seleccionarVehiculo();

        for (int j = 0; j < numeroVehiculos; j++) {
            if (vehiculos[j].getMatricula().equals(matriculaSeleccionada)) {
                JOptionPane.showMessageDialog(null, vehiculos[j]);
            }
        }
    }

    public static void main(String[] args) {
        ParqueMovil vehiculos = ParqueMovil.inicializaParqueMovil();

        String[] opciones = {"ALTA", "BAJA", "DATOS", "LISTADO", "SALIR"};
        int seleccion;
        do {
            seleccion = JOptionPane.showOptionDialog(null, "Elija una opción",
                    "MENÚ", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
            //if (seleccion == 0) ;
            switch (seleccion) {
                case 0:
                    if (!vehiculos.altaVehiculo())
                        JOptionPane.showMessageDialog(null, "Alta cancelada");
                    break;
                case 1:
                    if(vehiculos.numeroVehiculos>0)vehiculos.bajaVehiculo();
                    else JOptionPane.showMessageDialog(null,"Lista vacía",
                            "ERROR",JOptionPane.WARNING_MESSAGE);
                    break;
                case 2:
                    if(vehiculos.numeroVehiculos>0)vehiculos.mostrarDatos();
                    else JOptionPane.showMessageDialog(null,"Lista vacía",
                            "ERROR",JOptionPane.WARNING_MESSAGE);
                    break;
                case 3:
                    vehiculos.listadoVehiculos();
                    break;
            }

        } while (seleccion != 4 && seleccion != -1);

    }

}
