import javax.swing.*;
import java.util.Arrays;

public class ParqueMovil {

    private final int VEHICULOS_MAXIMOS = 50;
    private Vehiculo[] vehiculos = new Vehiculo[VEHICULOS_MAXIMOS];
    private int numeroVehiculos = 0;
    private final String nombreParque;

    public ParqueMovil(String nombre) {
        this.nombreParque = nombre;
    }

    public int getNumeroVehiculos() {
        return numeroVehiculos;
    }

    public String getNombreParque() {
        return nombreParque;
    }

    public void quiereVehiculosHechos() {
        int respuesta = JOptionPane.showConfirmDialog(null, "¿Desea inicializar el parque con vehículos ya definidos?", "Ventana de pregunta", JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);
        if (respuesta == JOptionPane.YES_OPTION) {
            Vehiculo[] vehiculosPrehechos = inicializarVehiculos();
            for (Vehiculo vehiculo : vehiculosPrehechos) {
                anyadeVehiculo(vehiculo);
            }
        }
    }

    public Vehiculo[] inicializarVehiculos() {
        Vehiculo[] vehiculosPredefinidos = {
                new Vehiculo("4561-BFN", MarcaVehiculo.FORD, 2500),
                new Vehiculo("5621-ALN", MarcaVehiculo.MERCEDES, 2800, 150),
                new Vehiculo("1145-BBA", MarcaVehiculo.FORD, 3400),
                new Vehiculo("9458-HRR", MarcaVehiculo.PEGASO, 2250, 200),
                new Vehiculo("7321-ADD", MarcaVehiculo.PEGASO, 2200),
        };
        return vehiculosPredefinidos;
    }

    public void menuPrincipal() {
        boolean salirONo = false;
        int eleccion;
        do {
            eleccion = JOptionPane.showOptionDialog(null, "¿Qué desea hacer?", "Parque Móvil",
                    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, OpcionesMenu.values(), OpcionesMenu.LISTA);
            if (eleccion==-1){
                salirONo=menuSalir();
            }else {
                OpcionesMenu opciones = OpcionesMenu.values()[eleccion];
                switch (opciones) {
                    case ALTA:
                        menuAnyadirVehiculo();
                        break;
                    case BAJA:
                        menuBorrarVehiculo();
                        break;
                    case DATOS:
                        if (numeroVehiculos == 0) {
                            JOptionPane.showMessageDialog(null, datosVehiculo());
                        } else {
                            comprobarDatosVehiculo();
                        }
                        break;
                    case LISTA:
                        JOptionPane.showMessageDialog(null, listadoVehiculosVentanaHTML(vehiculos), "Lista de vehículos", JOptionPane.PLAIN_MESSAGE);
                        break;
                    case SALIR:
                    default:
                        salirONo = menuSalir();
                }
            }
        } while (salirONo != true);
    }

    private void comprobarDatosVehiculo() {
        if (this.vehiculos == null || this.vehiculos.length==0) {
            JOptionPane.showMessageDialog(null, datosVehiculo());
            return;
        } else {
            Vehiculo vehiculo = menuSeleccionVehiculo();
            if (vehiculo == null) {
                return;
            } else {
                JOptionPane.showMessageDialog(null, datosVehiculo(vehiculo), "Datos del vehículo", JOptionPane.PLAIN_MESSAGE);
            }
        }
    }


    //Listado de todos los vehículos

    public String listadoVehiculosVentanaHTML(Vehiculo[] vehiculos) {
        String salida = "";
        salida += "<html><h2 >LISTA DE VEHÍCULOS</h2><br />";
        salida += "<hr>";
        salida += "<pre style=\"font-size:130%\">";
        if (numeroVehiculos == 0) {
            salida += "La lista de vehículos está vacía.<br/>";
        } else {
            salida += String.format("%10s %10s %13s %13s <br/>", "Matricula", "Marca", "Carga Máx.", "Kilometros");
            for (int i = 0; i <= numeroVehiculos - 1; i++) {
                salida += String.format("%10s %10s %9d kg %13d Km <br />", vehiculos[i].getMatricula(), vehiculos[i].getMarca(), vehiculos[i].getCargaMaxima(), vehiculos[i].getKilometros());
            }
        }
        salida += "</pre><hr/></html>";
        return salida;
    }

    //Datos de un vehículo

    public String datosVehiculo(Vehiculo vehiculo) {
        String salida = "";
        salida += "<html><h2 >DATOS DEL VEHÍCULO</h2><br />";
        salida += "<hr>";
        salida += "<pre style=\"font-size:130%\">";
        salida += String.format("%10s %10s %13s %13s <br/>", "Matricula", "Marca", "Carga Máx.", "Kilometros");
        salida += String.format("%10s %10s %9d kg %13d Km <br />", vehiculo.getMatricula(), vehiculo.getMarca(), vehiculo.getCargaMaxima(), vehiculo.getKilometros());

        salida += "</pre><hr/></html>";
        return salida;
    }

    public String datosVehiculo() {
        String salida = "";
        salida += "<html><h2 >DATOS DEL VEHÍCULO</h2><br />";
        salida += "<hr>";
        salida += "<pre style=\"font-size:130%\">";
        salida += "No hay ningún vehículo en el parque.<br/>";
        salida += "</pre><hr/></html>";
        return salida;
    }

    //Localizar vehículo

    public int posicion(String vehiculoBuscado) {
        for (int i = 0; i < numeroVehiculos; i++) {
            String elQuemiroEnMiArray = this.vehiculos[i].toString();
            if (elQuemiroEnMiArray.equals(vehiculoBuscado)) {
                return i;
            }
        }
        return -1;
    }


    //Todos los menús

    public boolean menuAnyadirVehiculo() {
        if (numeroVehiculos == this.vehiculos.length) {
            JOptionPane.showMessageDialog(null, "La lista de vehículos está completa", "Ventana de alerta", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        String matricula = escribirMatricula();
        if (matricula == null) {
            return false;
        }

        MarcaVehiculo marca = seleccionarMarca();
        if (marca == null) {
            return false;
        }

        int cargaMax = escribirCargaMaxima();
        if (cargaMax == -1) {
            return false;
        }

        int kilometros = menuKilometros();
        if (kilometros == -1) {
            return false;
        }

        anyadeVehiculo(new Vehiculo(matricula, marca, cargaMax, kilometros));
        return true;
    }

    private boolean menuBorrarVehiculo() {
        if (numeroVehiculos == 0) {
            JOptionPane.showMessageDialog(null, "La lista está vacía");
        } else {
            Vehiculo vehiculo = menuSeleccionVehiculo();
            if (vehiculo != null) {
                borrarVehiculo(posicion(vehiculo.toString()));
                return true;
            }
        }
        return false;
    }

    private boolean menuSalir() {
        return JOptionPane.showConfirmDialog(null, "¿Desea salir?", "Ventana de Salida",
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION;
    }

    private boolean menuCancelar() {
        return JOptionPane.showConfirmDialog(null, "¿Desea cancelar la operación?", "Ventana de cancelar",
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION;
    }

    private Vehiculo menuSeleccionVehiculo() {
        boolean haSeleccionadoVehiculo = false;
        Vehiculo[] vehiculosAElegir = Arrays.copyOf(vehiculos, numeroVehiculos);
        Vehiculo vehiculoSeleccionado;
        do {
            vehiculoSeleccionado = (Vehiculo) JOptionPane.showInputDialog(null, "Seleccione el vehículo:", "Menú selección de vehículos", JOptionPane.QUESTION_MESSAGE, null,
                    vehiculosAElegir, vehiculosAElegir[0]);

            if (vehiculoSeleccionado == null) {
                if (menuCancelar()) {
                    return null;
                }
            }

            if (vehiculoSeleccionado != null) {
                haSeleccionadoVehiculo = true;
            }
        } while (!haSeleccionadoVehiculo);

        return vehiculoSeleccionado;

    }


    private int menuKilometros() {
        int kilometrosVehiculo;
        boolean kilometrosDefinidos;
        int respuesta;
        do {
            respuesta = JOptionPane.showConfirmDialog(null, "¿El vehículo es nuevo?", "Vehículo nuevo", JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE);
            if (respuesta == -1) {
                if (menuCancelar()) {
                    return -1;
                }
            }
            if (respuesta == JOptionPane.YES_OPTION) {
                kilometrosVehiculo = 0;
                kilometrosDefinidos = true;
            } else {
                kilometrosVehiculo = escribirKilometros();
                kilometrosDefinidos = true;
            }
        } while (!kilometrosDefinidos);

        return kilometrosVehiculo;
    }

    //Añadir y borrar vehículos

    public boolean borrarVehiculo(int posicionVehiculo) {
        if (posicionVehiculo >= numeroVehiculos || posicionVehiculo < 0) {
            return false;
        }

        for (int i = posicionVehiculo; i < numeroVehiculos - 1; i++) {
            this.vehiculos[i] = this.vehiculos[i + 1];
        }
        numeroVehiculos--;
        return true;
    }

    public boolean anyadeVehiculo(Vehiculo vehiculo) {
        if (numeroVehiculos == VEHICULOS_MAXIMOS) {
            return false;
        }
        this.vehiculos[numeroVehiculos++] = vehiculo;
        return true;
    }

    //Escribir datos

    private String escribirMatricula() {
        String matricula;
        do {
            matricula = JOptionPane.showInputDialog(null, "Escriba la matrícula del vehículo.", "Matrícula del vehículo", JOptionPane.QUESTION_MESSAGE);
            if (matricula == null) {
                if (menuCancelar()) {
                    return null;
                } else {
                    matricula = "";
                }
            }
            for (int i = 0; i < numeroVehiculos; i++) {
                if (vehiculos[i].getMatricula().equals(matricula)) {
                    JOptionPane.showMessageDialog(null, "La matrícula que me has escrito ya existe, por favor, introduzca otra.", "Matrícula erronea", JOptionPane.ERROR_MESSAGE);
                    matricula = "";
                }
            }
        } while (matricula.equals(""));

        return matricula;
    }

    private MarcaVehiculo seleccionarMarca() {
        MarcaVehiculo marca;
        boolean haElegidoMarca = false;
        do {
            marca = (MarcaVehiculo) JOptionPane.showInputDialog(null, "Seleccione una marca del vehículo", "Marca del vehículo", JOptionPane.QUESTION_MESSAGE,
                    null, MarcaVehiculo.values(), MarcaVehiculo.FORD);
            if (marca == null) {
                if (menuCancelar()) {
                    return null;
                }
            }
            if (marca != null) {
                haElegidoMarca = true;
            }
        } while (!haElegidoMarca);

        return marca;
    }

    private int escribirCargaMaxima() {
        String cargaMaxima;
        do {
            cargaMaxima = JOptionPane.showInputDialog(null, "Escriba la carga máxima del vehículo.",
                    "Carga Máxima del vehiculo", JOptionPane.QUESTION_MESSAGE);
            if (cargaMaxima == null) {
                if (menuCancelar()) {
                    return -1;
                } else {
                    cargaMaxima = "";
                }
            }
        } while (cargaMaxima.equals(""));
        return Integer.parseInt(cargaMaxima);
    }

    private int escribirKilometros() {
        String kilometrosVehiculo;
        do {
            kilometrosVehiculo = JOptionPane.showInputDialog(null, "Escriba los kilometros del vehículo.",
                    "Kilometros del vehiculo", JOptionPane.QUESTION_MESSAGE);
            if (kilometrosVehiculo == null) {
                if (menuCancelar()) {
                    return -1;
                } else {
                    kilometrosVehiculo = "";
                }
            }
        } while (kilometrosVehiculo.equals(""));
        return Integer.parseInt(kilometrosVehiculo);

    }
}

