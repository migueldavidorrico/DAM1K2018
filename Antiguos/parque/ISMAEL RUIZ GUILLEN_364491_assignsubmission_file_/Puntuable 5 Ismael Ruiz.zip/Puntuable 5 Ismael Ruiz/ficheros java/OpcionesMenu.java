public enum OpcionesMenu {
    ALTA,BAJA,DATOS,LISTA,SALIR;
}
