public enum MarcaVehiculo {
    MERCEDES,PEGASO,FORD;
}
