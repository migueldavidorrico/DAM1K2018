public class Vehiculo {
    private final String matricula;
    private final MarcaVehiculo marca;
    private final int cargaMaxima;
    private int kilometros;

    public Vehiculo(String matricula, MarcaVehiculo marca, int cargaMaxima) {
        this(matricula, marca, cargaMaxima, 0);
    }

    public Vehiculo(String matricula, MarcaVehiculo marca, int cargaMaxima, int kilometros) {
        this.matricula = matricula;
        this.marca = marca;
        this.cargaMaxima = cargaMaxima;
        this.kilometros = kilometros;
    }


    public int getKilometros() {
        return this.kilometros;
    }

    public void setKilometros(int kilometros) {
        this.kilometros = kilometros;
    }

    public String getMatricula() {
        return this.matricula;
    }

    public MarcaVehiculo getMarca() {
        return this.marca;
    }

    public int getCargaMaxima() {
        return this.cargaMaxima;
    }

    @Override
    public String toString() {
        return this.getMatricula() + " " + this.getMarca();
    }
}
