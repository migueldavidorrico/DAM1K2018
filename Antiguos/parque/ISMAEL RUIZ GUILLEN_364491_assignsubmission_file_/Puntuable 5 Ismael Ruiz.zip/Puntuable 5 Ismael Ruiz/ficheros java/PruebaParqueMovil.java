public class PruebaParqueMovil {
    public static void main(String[] args) {
        ParqueMovil parque=new ParqueMovil("Parque Nuevo");
        parque.quiereVehiculosHechos();
        parque.menuPrincipal();
    }
}
