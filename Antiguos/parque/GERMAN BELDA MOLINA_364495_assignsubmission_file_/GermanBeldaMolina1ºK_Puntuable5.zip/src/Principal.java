public class Principal {
    public static void main(String[] args) {

        ParqueMovil German = new ParqueMovil("Parque1");

        German.preguntaIniciaParque();
        German.menuprincipal();
    }
}
