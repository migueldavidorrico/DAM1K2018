public enum MarcaCoche {
    FORD,MERCEDES,PEGASO
}
