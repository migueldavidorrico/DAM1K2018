public enum OpcionesMenu {
    ALTA,BAJA,MOSTRAR,LISTADO,SALIR
}
